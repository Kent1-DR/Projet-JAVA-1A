//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

public class FabriquePoint {
	/**
	 * Permet de cr�er un point
	 * 
	 * @param type permet de chercher de qule type est le point
	 * @param xAngle d�finition de l'abscisse du nouveau point
	 * @param yRayon d�finition de l'ordonn� du nouveau point
	 * @return retourne a l'utilisateur le nouveau point
	 */
	
	//d�finition de la m�thode create
    public static interpoint create(String type, double xAngle, double yRayon) {
        interpoint point = null; //on initialise la variable point a null
        
        if (type.equals("Point")) //si char=Point
        {
            point = new Point(xAngle, yRayon); //on cr�� un point a l'aide de la classe Point
        } 
        
        else if (type.equals("Point2")) { //si char=Point2
            point = new point2(xAngle, yRayon); //on cr�� un point a l'aide de la classe Point2
        }
        
        return point;
    }
}

