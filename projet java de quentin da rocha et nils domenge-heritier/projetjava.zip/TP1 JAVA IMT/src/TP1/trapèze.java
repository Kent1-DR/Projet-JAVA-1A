//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

/**
 * Fabrique un trap�ze
 * 
 * @param sommet1 d�finit le premier sommet du trap�ze
 * @param sommet2 d�finit le deuxieme sommet du trap�ze
 * @param sommet3 d�finit le troisieme sommet du trap�ze
 * @param sommet4 d�finit le quatrieme sommet du trap�ze
 */
public class trap�ze extends Quadri {

	public trap�ze(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) {
		super(sommet1, sommet2, sommet3, sommet4);
	}


	/**
	 * Affiche la d�finition d'un cerfvolant
	 * 
	 * @return fournit une description d'un cerfvolant
	 */
	public static String propriete() {
		return "Un trap�ze est un quadrilat�re poss�dant deux c�t�s oppos�s parall�les. Ces deux c�t�s parall�les sont appel�s bases.";
	}

	
	/**
	 * Affiche le type de cerfvolant
	 * 
	 */
	public static String type() {
		return "Je suis un trap�ze.";
	}

	@Override
	/**
	 * Fournit l'affichage global
	 * 
	 * @return Retourne dans la console l'int�gralit� des caract�ristiques d'un carr�
	 */
	public String toString() {
		return type() + " " + propriete() + " " + this.coordonnees();
	}
}

