//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

/**
 * Definition de la classe Point2
 * 
 * angle Abscisse du point dans un syst�me de coordonn�es polaires
 * rayon Ordonnes du point dans un syst�me de coordonn�es polaires
 */

public class point2 implements interpoint{
    private final double angle;
    private final double rayon;

/**
 * 
 * 
 * @param angle on convertit la valeur de l'angle en radian
 * @param rayon
 */
    public point2(double angle, double rayon) {
        this.angle = Math.toRadians(angle);
        this.rayon = rayon;
    }

    
    /**
     * getX() retournent l�abscisse dans un rep�re cart�sien.
     * getY() retournent l�ordonnes dans un rep�re cart�sien.
     * 
     */
    public double getX() {
        return Math.round(rayon * Math.cos(angle) * 100.0) / 100.0;
    }

    public double getY() {
        return Math.round(rayon * Math.sin(angle) * 100.0) / 100.0;
    }

}
