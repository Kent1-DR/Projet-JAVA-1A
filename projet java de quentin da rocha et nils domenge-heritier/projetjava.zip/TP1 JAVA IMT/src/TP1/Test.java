//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

/**
 * Cr�ation d'une classe de TEST
 * 
 * @author king1
 *
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
