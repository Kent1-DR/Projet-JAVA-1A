//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

public class Rectangle extends Quadri {
	
	/**
	 * Fabrique un Rectangle
	 * 
	 * @param sommet1 d�finit le premier sommet du Rectangle
	 * @param sommet2 d�finit le deuxieme sommet du Rectangle
	 * @param sommet3 d�finit le troisieme sommet du Rectangle
	 * @param sommet4 d�finit le quatrieme sommet du Rectangle
	 */
	public Rectangle(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) {
		super(sommet1, sommet2, sommet3, sommet4);
	}


	
	public void affiche()
	{

		System.out.println(this);
	}
	
	
	/**
	 * Affiche la d�finition d'un cerfvolant
	 * 
	 * @return fournit une description d'un cerfvolant
	 */
	public String Type() {
		return "Un rectangle est un quadrilat�re dont les quatre angles sont droits. Et dont la largeur et la longueur sont de longeur �gales";
	}

	/**
	 * Affiche le type de Rectangle
	 * 
	 */
	public static String type() {
		return "Je suis un rectangle.";
	}

	@Override
	/**
	 * Affiche les propriete du cerfvolant
	 * 
	 * @return Fournit le type de quadrilatere
	 */
	public String toString() {
		return type() + " " + Type() + " " + this.coordonnees();
	}


}
