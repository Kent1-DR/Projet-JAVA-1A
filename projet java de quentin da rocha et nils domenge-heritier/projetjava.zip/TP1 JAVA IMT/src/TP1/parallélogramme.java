//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

public class parall�logramme extends Quadri {

	/**
	 * Fabrique un parall�logramme
	 * 
	 * @param sommet1 d�finit le premier sommet du parall�logramme
	 * @param sommet2 d�finit le deuxieme sommet du parall�logramme
	 * @param sommet3 d�finit le troisieme sommet du parall�logramme
	 * @param sommet4 d�finit le quatrieme sommet du parall�logramme
	 */
	
	public parall�logramme(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) {
		super(sommet1, sommet2, sommet3, sommet4);
	}

	/**
	 * Affiche la d�finition d'un parall�logramme
	 * 
	 * @return fournit une description d'un parall�logramme
	 */
	public static String propriete() {
		return "Un parall�logramme est un quadrilat�re dont les segments diagonaux se coupent en leurs milieux.";
	}

	
	/**
	 * Affiche le type de parall�logramme
	 * 
	 */
	public static String type() {
		return "Je suis un parall�logramme.";
	}

	@Override
	/**
	 * Fournit l'affichage global
	 * 
	 * @return Retourne dans la console l'int�gralit� des caract�ristiques d'un parall�logramme
	 */
	public String toString() {
		return type() + " " + propriete() + " " + this.coordonnees();
	}
}
