//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

import TP1.*;

//definition de la classe point

public class ProgPrincipal {

	/**
	 * Constructeur du programme principal on l'on va construire tout nos quadrilatere et crer nos points
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
        interpoint sommet1 = FabriquePoint.create("Point",0, 4);
        interpoint sommet2 = FabriquePoint.create("Point",4, 8);
        interpoint sommet3 = FabriquePoint.create("Point",12, 14);
        interpoint sommet4 = FabriquePoint.create("Point",7, 8);
        Quadri quadrilatere = new Quadri(sommet1, sommet2, sommet3, sommet4);
        quadrilatere.affiche();


        sommet1 = new Point(0, 0);
        sommet2 = new Point(3, 7);
        sommet3 = new Point(8, 8);
        sommet4 = new Point(7, 1);
        trap�ze trapeze = new trap�ze(sommet1, sommet2, sommet3, sommet4);
        trapeze.affiche();
        
        sommet1 = new Point(0, 0);
		sommet2 = new Point(0, 6);
		sommet3 = new Point(6, 0);
		sommet4 = new Point(6, 6);
        carr� carre = new carr�(sommet1, sommet2, sommet3, sommet4);
        carre.affiche();

        sommet1 = new Point(0, 0);
        sommet2 = new Point(3, 7);
        sommet3 = new Point(8, 8);
        sommet4 = new Point(7, 1);
        cerfvolant cerfVolant = new cerfvolant(sommet1, sommet2, sommet3, sommet4);
        cerfVolant.affiche();
        
        sommet1 = new Point(0, 0);
        sommet2 = new Point(3, 7);
        sommet3 = new Point(8, 8);
        sommet4 = new Point(7, 1);
        parall�logramme parallelogramme = new parall�logramme(sommet1, sommet2, sommet3, sommet4);
        parallelogramme.affiche();

        sommet1 = new Point(0, 0);
        sommet2 = new Point(3, 7);
        sommet3 = new Point(8, 8);
        sommet4 = new Point(7, 1);
        Rectangle rectangle = new Rectangle(sommet1, sommet2, sommet3, sommet4);
        rectangle.affiche();
        
        sommet1 = new Point(0, 0);
        sommet2 = new Point(3, 7);
        sommet3 = new Point(8, 8);
        sommet4 = new Point(7, 1);
        Losange losange = new Losange(sommet1, sommet2, sommet3, sommet4);
        losange.affiche();
        
        point2 point2 = new point2(90,1);
        System.out.println(point2.getX() + point2.getY());

	}
}
