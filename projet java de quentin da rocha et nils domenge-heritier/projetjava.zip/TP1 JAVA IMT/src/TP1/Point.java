//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

/**
 * Cr�eation de la classe Point
 * avec d�finition de deux attributs x et y
 *
 *x d�finit l'abscisse du point
 *y d�finit l'ordonne du point
 */
public class Point implements interpoint {
	private double y;
	private double x;
	
	public Point(double xAngle, double yRayon) {
		this.x = xAngle;
		this.y = yRayon;
	}
	
	/**
	 * Definition des getters et des setters
	 * 
	 * getX() recupere l'abscisse du point
	 * getY() recupere l'ordonnes du point
	 * setX() d�finit l'abscisse du point
	 * setY() d�finit l'ordonnes du point
	 */
	public double getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public double getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	
	/**
	 * Constructeur dans lequel nous allons creer des points
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
	
		Point sommet1 = new Point(0,7);
		Point sommet2 = new Point(3,6);
		Point sommet3 = new Point(2,8);
		Point sommet4 = new Point(6,10);
		
		System.out.println(sommet1);
		
	}
	
	/**
	 * Red�finition de la methode ToString
	 * 
	 * 
	 */
	public String toString()
	{
		String chaine;
		chaine = "Mes sommets ont pour coordonnes" + "(" +this.getX()+ ")" + "(" +this.getY()+ ")";
		return chaine;
	}
}

