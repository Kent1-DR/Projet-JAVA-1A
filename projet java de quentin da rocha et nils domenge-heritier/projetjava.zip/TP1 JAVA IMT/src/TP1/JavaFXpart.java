//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;

import java.util.List;

public class JavaFXpart extends Application {
    @Override
    public void start(Stage stage) {
        Label displayPropriete = new Label();
        displayPropriete.setAlignment(Pos.CENTER);
        Polygon polygon = new Polygon();
        Quadri baseQuadrilatere = new Quadri(
                new Point(0, 0), new Point(0, 0),
                new Point(0, 0), new Point(0, 0)
        );
        polygon.getPoints().addAll(baseQuadrilatere.toDoubleList());

        
        /*
         * Cr�ation du bouton rectangle et du dessin de la figure
         * a l'aide des coordonnes (50,50);(250,50));(250,150) et (50,150)
         */
        
        Button buttonRectangle = new Button("Rectangle");
        buttonRectangle.setOnAction(event -> {
            Rectangle rectangle = new Rectangle(
                    new Point(50, 50), new Point(250, 50),
                    new Point(250, 150), new Point(50, 150)
            );
            
            List<Double> newCoor = rectangle.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(rectangle.toString());
            rectangle.affiche();
        });
        
       
        /*
         * Cr�ation du parrallelogramme et du dessin de la figure
         * a l'aide des coordonnes (20,20);(170,20);(210,110) et (170,120)
         */
        Button buttonParallelogramme = new Button("Parallelogramme");
        buttonParallelogramme.setOnAction(event -> {
            parall�logramme parallelogramme = new parall�logramme(
                    new Point(20, 20), new Point(170, 20),
                    new Point(210, 110), new Point(170, 120)
            );
            List<Double> newCoor = parallelogramme.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(parallelogramme.toString());
            parallelogramme.affiche();
        });

        /*
         * Cr�ation du bouton trap�ze et du dessin de la figure
         *  a l'aide des coordonnes (50,0);(175,0);(200,100) et (0,100)
         */
        Button buttonTrapeze = new Button("Trap�ze");
        buttonTrapeze.setOnAction(event -> {
            trap�ze trapeze = new trap�ze(
                    new Point(50, 0), new Point(175, 0),
                    new Point(200, 100), new Point(0, 100)
            );
            List<Double> newCoor = trapeze.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(trapeze.toString());
            trapeze.affiche();
        });

        /*
         * Cr�ation du bouton quadrilatere et du dessin de la figure
         *  a l'aide des coordonnes (56,0);(155,25);(100,100) et (30,60)
         */
        Button buttonQuadri = new Button("Quadrilat�re");
        buttonQuadri.setOnAction(event -> {
            Quadri quadrilatere = new Quadri(
                    new Point(56, 0), new Point(155, 25),
                    new Point(100, 100), new Point(30, 60)
                    );
            List<Double> newCoor = quadrilatere.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(quadrilatere.toString());
            quadrilatere.affiche();
        });
        
        /*
         * Cr�ation du bouton losange et du dessin de la figure
         *  a l'aide des coordonnes (100,0);(200,100);(100,200) et (0,100)
         */
        Button buttonLosange = new Button("Losange");
        buttonLosange.setOnAction(event -> {
            Losange losange = new Losange(
                    new Point(100, 0), new Point(200, 100),
                    new Point(100, 200), new Point(0, 100)
            );
            List<Double> newCoor = losange.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(losange.toString());
            losange.affiche();
        });

        
        /*
         * Cr�ation du bouton cerf-volant et du dessin de la figure
         *  a l'aide des coordonnes (100,0);(150,0);(100,200) et (50,50)
         */
        Button buttonCerf = new Button("Cerf-volant");
        buttonCerf.setOnAction(event -> {
            cerfvolant cerfVolant = new cerfvolant(
                    new Point(100, 0), new Point(150, 50),
                    new Point(100, 200), new Point(50, 50)
            );
            List<Double> newCoor = cerfVolant.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(cerfVolant.toString());
            cerfVolant.affiche();
        });

        /*
         * Cr�ation du bouton carr� et du dessin de la figure
         *  a l'aide des coordonnes (50,0);(175,0);(200,100) et (0,100)
         */
        Button buttonCarre = new Button("Carr�");
        buttonCarre.setOnAction(event -> {
            carr� carre = new carr�(
                    new Point(0, 0), new Point(200, 0),
                    new Point(200, 200), new Point(0, 200)
            );
            List<Double> newCoor = carre.toDoubleList();
            for (int i = 0; i < newCoor.size(); i++) {
                polygon.getPoints().set(i, newCoor.get(i));
            }
            displayPropriete.setText(carre.toString());
            carre.affiche();
        });

        HBox buttonBox = new HBox(25);
        buttonBox.getChildren().addAll(buttonRectangle, buttonParallelogramme, buttonCerf, buttonTrapeze, buttonLosange,buttonQuadri, buttonCarre);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(30));
        

        BorderPane pane = new BorderPane();
        VBox polyBox = new VBox();
        polyBox.getChildren().addAll(polygon);
        polyBox.setAlignment(Pos.CENTER);
        pane.setCenter(polyBox);
        pane.setBottom(buttonBox);

     

        pane.setTop(displayPropriete);
        pane.setLeft(new VBox());
        pane.setRight(new VBox());

        //Creating a scene object
        Scene scene = new Scene(pane, 1000, 700);
        stage.setTitle("Figures");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

