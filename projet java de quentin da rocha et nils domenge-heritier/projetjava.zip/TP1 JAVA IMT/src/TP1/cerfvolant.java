//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

public class cerfvolant extends Quadri { //cr�ation de la classe cerfvolant

	/**
	 * Fabrique un cerfvolant
	 * 
	 * @param sommet1 d�finit le premier sommet du cerfvolant
	 * @param sommet2 d�finit le deuxieme sommet du cerfvolant
	 * @param sommet3 d�finit le troisieme sommet du cerfvolant
	 * @param sommet4 d�finit le quatrieme sommet du cerfvolant
	 */
	
    public cerfvolant(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) { //initialisation du constructeur
        super(sommet1, sommet2, sommet3, sommet4); //ici on recupere les sommets definit dans la classe mere (Quadri) grace a l'appel de super
    }

    
    /**
	 * Affiche le type de cerfvolant
	 * 
	 */
    
    public void affiche() //cr�ation de la m�thode affiche
	{
		
		System.out.println(this); //retourne la premiere methode suivant l'appel
	}
    
    
    /**
	 * Affiche la d�finition d'un cerfvolant
	 * 
	 * @return fournit une description d'un cerfvolant
	 */
    public static String propriete() { //cr�ation de la m�thode propriete
        return "Un cerf-volant est un quadrilat�re dont une des diagonales est un axe de sym�trie.";
    }

    
    
    
    /**
	 * Affiche les propriete du cerfvolant
	 * 
	 * @return Fournit le type de quadrilatere
	 */
    public static String type() { //cr�ation de la m�thode Type()
        return "Je suis un cerf-volant.";
    }

    
    @Override
    /**
	 * Fournit l'affichage global
	 * 
	 * @return Retorune dans la console l'int�gralit� des caract�ristiques d'un carr�
	 */
    public String toString() { //red�finition de la methode ToString()
        return type() + " " + propriete() + " " + this.coordonnees();
    }

}

