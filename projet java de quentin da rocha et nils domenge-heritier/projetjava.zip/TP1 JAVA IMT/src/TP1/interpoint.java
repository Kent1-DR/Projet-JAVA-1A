//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

/**
 * 
 * @author king1
 *
 *
 */
public interface interpoint {
    double getX();
    double getY();
}

