//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

public class Losange extends Quadri {
	
	/**
	 * Fabrique un losange
	 * 
	 * @param sommet1 d�finit le premier sommet du losange
	 * @param sommet2 d�finit le deuxieme sommet du losange
	 * @param sommet3 d�finit le troisieme sommet du losange
	 * @param sommet4 d�finit le quatrieme sommet du losange
	 */

	public Losange(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) {
        super(sommet1, sommet2, sommet3, sommet4);
	}

	/**
	 * Affiche la d�finition d'un Losange
	 * 
	 * @return fournit une description d'un Losange
	 */
	public static String propriete() {
		return "Un losange est un quadrilat�re dont les c�t�s ont tous la m�me longueur1, ou encore un parall�logramme ayant au moins deux c�t�s cons�cutifs de m�me longueur.";
	}

	/**
	 * Affiche le type de Losange
	 * 
	 */
	public static String type() {
		return "Je suis un losange.";
	}

	@Override
	/**
	 * Fournit l'affichage global
	 * 
	 * @return Retorune dans la console l'int�gralit� des caract�ristiques d'un carr�
	 */
	public String toString() {
		return type() + " " + propriete() + " " + this.coordonnees();
	}

}

