//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1;

import java.util.Arrays;
import java.util.List;

import TP1.Point;

/**
 * 
 * 
 * @author king1
 *
 */
public class Quadri {
	
	public final  interpoint sommet1;
	private final interpoint sommet2;
	protected final interpoint sommet3;
	private final interpoint sommet4;
	
	
	/**
	 * Fabrique un Quadri
	 * 
	 * @param sommet1 d�finit le premier sommet du Quadri
	 * @param sommet2 d�finit le deuxieme sommet du Quadri
	 * @param sommet3 d�finit le troisieme sommet du Quadri
	 * @param sommet4 d�finit le quatrieme sommet du Quadri
	 */
	public Quadri(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) {
		this.sommet1 = sommet1;
		this.sommet2 = sommet2;
		this.sommet3 = sommet3;
		this.sommet4 = sommet4;
		// TODO Auto-generated constructor stub
	}

	/**
	 * Affiche le type du Quadri
	 * 
	 */
	public String Type() {
		
		return "quelconque";
	}
	
/**
 * recupere les coordonnes des sommets du Quardi
 * 
 * @return retourne a l'utilisateurs les sommets du Quardi
 */
	public String coordonnees() {
		
		return "Mes sommets ont pour coordonnes" + "(" + sommet1.getX() + "," + sommet1.getY() + ")" + "(" + sommet2.getX() + "," + sommet2.getY() + ")" + "(" + sommet3.getX() + "," + sommet3.getY() + ")" + "et" + "(" + sommet4.getX() + "," + sommet4.getY() + ")";
	}

	/**
	 * Affiche a l'utilisateur le retour de la methode d'apres (toString) 
	 * 
	 */
	public void affiche()
	{
		
		System.out.println(this);
	}
	
	
	public List<Double> toDoubleList() {
		return Arrays.asList(
				sommet1.getX(), sommet1.getY(),
				sommet2.getX(), sommet2.getY(),
				sommet3.getX(), sommet3.getY(),
				sommet4.getX(), sommet4.getY()
		);
	}


	
	/**
	 * Fournit l'affichage global
	 * 
	 * @return Retourne dans la console l'int�gralit� des caract�ristiques d'un carr�
	 */
	public String toString()
	{
		String chaine1;
		chaine1 = "Je suis un quadrilatere" + " " + this.Type() + " " + this.coordonnees();
		return chaine1;
	}

}
