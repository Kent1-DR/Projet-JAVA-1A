//Quentin DA ROCHA, NILS DOMENGE-HERITIER

package TP1; //on d�finit le package ou est stock� la classe

public class carr� extends Quadri { 
	
	/**
	 * Fabrique un carr�
	 * 
	 * @param sommet1 d�finit le premier sommet du carr�
	 * @param sommet2 d�finit le deuxieme sommet du carr�
	 * @param sommet3 d�finit le troisieme sommet du carr�
	 * @param sommet4 d�finit le quatrieme sommet du carr�
	 */
	
	public carr�(interpoint sommet1, interpoint sommet2, interpoint sommet3, interpoint sommet4) { //initialisation du constructeur
		super(sommet1, sommet2, sommet3, sommet4); //ici on recupere les sommets definit dans la classe mere (Quadri) grace a l'appel de super
	}

	
	/**
	 * Affiche le type de quadrilatere
	 * 
	 */
	
	public void affiche() 
	{
		
		System.out.println(this);
	}

	
	/**
	 * Affiche la d�finition d'un carr�
	 * 
	 * @return fournit une description d'un carr�
	 */
	
	public static String propriete() { 
		return "Un carr� est un quadrilat�re particulier, � la fois\r\n" + 
				"rectangle et losange. Ses cot�s sont parall�les deux � deux, de longueur �gales et\r\n" + 
				"orthogonaux. Ses diagonales sont orthogonales.";
	}

	
	/**
	 * Affiche les propriete du carr�
	 * 
	 * @return Fournit les dimensions du carr� (comme c'est un carr� un seul cot� suffit pour d�finir sa longueur)
	 */
	
	public String typeCarre() { 
		return "Je suis un carr� de " + sommet3.getX() + "cm de c�t�.";
	}


	@Override
	/**
	 * Fournit l'affichage global
	 * 
	 * @return Retorune dans la console l'int�gralit� des caract�ristiques d'un carr�
	 */
	public String toString() { 
		return typeCarre() + " " + propriete() + " " + this.coordonnees(); 
	}


}
